# TARIK
## Introduction 
Tarik is a location based game written in go. This repo contains the server-side application.
## Enviroment Setup
### Install Go
[Download the Go distribution](https://golang.org/doc/install)

### Dependencies
Use ```go get``` command to find and download all dependencies.

### Custom Package 
[touristmedia](http://localhost:6060/pkg/github.com/tarik-app/TARIK/touristmedia/)

### Grade
[![Go Report Card](https://goreportcard.com/badge/github.com/tarik-app/TARIK)](https://goreportcard.com/report/github.com/tarik-app/TARIK)


